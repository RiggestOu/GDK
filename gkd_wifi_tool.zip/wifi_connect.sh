#!/bin/sh
# GKD mini WiFi 手动连接脚本
# 用法：把此脚本 + wifi.conf 放到 SD 卡根目录或 /media/roms/
# 在设备上执行: sh /media/roms/wifi_connect.sh

LOG="/media/roms/wifi_log.txt"
CONF="/media/roms/wifi.conf"

echo "=== WiFi 连接脚本 $(date) ===" > "$LOG"

# 检查配置文件
if [ ! -f "$CONF" ]; then
    echo "[ERROR] 找不到 $CONF" >> "$LOG"
    echo "请先编辑 wifi.conf 填入 SSID 和密码"
    exit 1
fi

# 读取配置
SSID=$(grep '^SSID=' "$CONF" | cut -d= -f2)
PSK=$(grep '^PSK=' "$CONF" | cut -d= -f2)

if [ -z "$SSID" ] || [ -z "$PSK" ]; then
    echo "[ERROR] wifi.conf 中 SSID 或 PSK 为空" >> "$LOG"
    exit 1
fi

echo "目标 SSID: $SSID" >> "$LOG"

# 杀掉残留的 wpa_supplicant 和 dhcp
killall wpa_supplicant 2>/dev/null
killall udhcpc 2>/dev/null
sleep 1

# 查找无线接口
IFACE=$(iw dev 2>/dev/null | grep Interface | awk '{print $2}')
if [ -z "$IFACE" ]; then
    IFACE="wlan0"  # 默认值
fi
echo "无线接口: $IFACE" >> "$LOG"

# 启动接口
ifconfig $IFACE up 2>>"$LOG"
sleep 2

# 生成 wpa_supplicant 配置（写到 tmpfs 可写目录）
WPACONF=/tmp/wpa_gkd.conf
cat > "$WPACONF" << EOF
ctrl_interface=/var/run/wpa_supplicant
update_config=1
network={
    ssid="$SSID"
    psk="$PSK"
    key_mgmt=WPA-PSK
    proto=WPA2
    pairwise=CCMP
    group=CCMP
    scan_ssid=1
    priority=5
}
EOF
echo "wpa_supplicant.conf 已生成" >> "$LOG"

# 启动 wpa_supplicant（后台）
wpa_supplicant -B -i$IFACE -c"$WPACONF" -dd -f/tmp/wpa_debug.log 2>>"$LOG"
sleep 3

# 等待关联（最多 15 秒）
echo "开始关联..." >> "$LOG"
for i in $(seq 1 15); do
    STATUS=$(wpa_cli status 2>/dev/null | grep wpa_state | cut -d= -f2)
    echo "[$i] wpa_state=$STATUS" >> "$LOG"
    if [ "$STATUS" = "COMPLETED" ]; then
        echo "关联成功！" >> "$LOG"
        break
    fi
    sleep 1
done

# 获取 IP（udhcpc）
echo "请求 DHCP..." >> "$LOG"
udhcpc -i $IFACE -n -q -t 10 2>>"$LOG"
sleep 2

# 报告结果
IP=$(ifconfig $IFACE 2>/dev/null | grep 'inet addr' | awk '{print $2}' | cut -d: -f2)
GW=$(route -n 2>/dev/null | grep $IFACE | grep UG | awk '{print $2}')

echo "" >> "$LOG"
echo "=== 最终状态 ===" >> "$LOG"
echo "IP 地址: ${IP:-未获取}" >> "$LOG"
echo "网关: ${GW:-无}" >> "$LOG"
wpa_cli status >> "$LOG" 2>/dev/null

if [ -n "$IP" ]; then
    echo "" >> "$LOG"
    echo "WiFi 连接成功！IP=$IP" >> "$LOG"
    # 测试连通性
    ping -c 2 -W 3 8.8.8.8 2>>"$LOG" && echo "外网连通 ✓" >> "$LOG" || echo "外网不通 ✗" >> "$LOG"
fi

echo "=== 完成 ===" >> "$LOG"
echo "日志已写入 $LOG"
